# Taana — Full-Stack Handloom Textile Store

A complete storefront: animated frontend, Node.js/Express API, SQLite database,
JWT authentication, an admin panel, and Stripe payments.

```
taana-fullstack/
├── frontend/
│   └── index.html          ← the storefront (open with Live Server, not double-click)
├── backend/
│   ├── server.js            ← Express entry point
│   ├── config/db.js         ← SQLite schema + connection
│   ├── middleware/auth.js   ← JWT auth + admin guard
│   ├── routes/               ← auth, products, orders, payment, admin APIs
│   ├── public/admin/        ← admin panel (login.html, dashboard.html)
│   ├── seed.js               ← creates the first admin + sample products
│   └── .env.example          ← copy to .env and fill in
└── README.md
```

## 1. Prerequisites

- [Node.js](https://nodejs.org) 18 or newer
- [Visual Studio Code](https://code.visualstudio.com)
- The **Live Server** VS Code extension (for the frontend) — search "Live Server" by Ritwick Dey in the Extensions panel
- A free [Stripe](https://dashboard.stripe.com/register) account (test mode is free, no real card needed)

## 2. Open the project in VS Code

1. Unzip this folder.
2. `File → Open Folder…` and select `taana-fullstack`.

## 3. Set up the backend

Open a terminal in VS Code (`` Ctrl+` ``) and run:

```bash
cd backend
npm install
cp .env.example .env
```

Now open `.env` and fill in:

- `JWT_SECRET` — any long random string (e.g. mash your keyboard)
- `STRIPE_SECRET_KEY` — from https://dashboard.stripe.com/test/apikeys (starts with `sk_test_`)
- `STRIPE_WEBHOOK_SECRET` — see step 6 below for how to get this
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — the login you'll use for the admin panel

Create the database and seed it with an admin account + sample products:

```bash
npm run seed
```

Start the API:

```bash
npm start
```

You should see:
```
Taana API running on http://localhost:4000  (admin panel: http://localhost:4000/admin)
```

Leave this terminal running.

## 4. Run the storefront

The frontend is plain HTML/CSS/JS — no build step. In VS Code:

1. Right-click `frontend/index.html` → **Open with Live Server**.
   (Don't just double-click the file — opening it as `file://` blocks the API requests in some browsers. Live Server serves it at `http://localhost:5500`.)
2. The homepage loads products live from the API. Register a new account, add items to the bag, and check out.

If Live Server uses a different port than 5500, update `CLIENT_URL` in `backend/.env` to match, and restart the backend.

## 5. Use the admin panel

Go to **http://localhost:4000/admin/login.html** and log in with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` you set in `.env`.

From the dashboard you can:
- See revenue, order and customer stats
- Add, edit, and delete products (name, price, category, stock, image URL)
- View all customer orders and update their status (pending → paid → shipped → delivered)

## 6. Set up Stripe payments (test mode)

1. Get your test secret key from https://dashboard.stripe.com/test/apikeys and put it in `STRIPE_SECRET_KEY`.
2. Install the [Stripe CLI](https://docs.stripe.com/stripe-cli) to forward webhook events to your local server:
   ```bash
   stripe login
   stripe listen --forward-to localhost:4000/api/payment/webhook
   ```
   This prints a webhook signing secret starting with `whsec_...` — put that in `STRIPE_WEBHOOK_SECRET` in `.env`, then restart the backend.
3. On checkout, you'll be redirected to Stripe's hosted payment page. Use a [Stripe test card](https://docs.stripe.com/testing#cards) like:
   - Card number: `4242 4242 4242 4242`
   - Any future expiry date, any CVC, any postal code
4. On success, Stripe redirects back to the storefront and the webhook marks the order as **paid** — check the admin Orders tab to confirm.

You don't need the Stripe CLI running for the checkout redirect itself to work — you only need it for the order to automatically flip to "paid". Without it, you can still mark orders paid manually from the admin panel.

## 7. How the pieces talk to each other

- **Frontend → API**: `frontend/index.html` calls `http://localhost:4000/api/...` for products, login/register, and checkout. Change the `API_BASE` constant near the top of the `<script>` block if you deploy the API elsewhere.
- **Auth**: on login/register, the API returns a JWT which the frontend stores in `localStorage` and sends as `Authorization: Bearer <token>` on every request that needs it (placing an order, paying).
- **Admin panel**: a separate static site under `/admin`, using the same `/api/auth/login` endpoint — it just checks that `role === 'admin'`.
- **Database**: SQLite file at `backend/data/taana.db`, created automatically on first run. No separate database server to install. (To move to Postgres/MySQL later, only `config/db.js` and the SQL calls in `routes/` need to change.)

## 8. Going to production (checklist)

- Swap SQLite for a hosted database (Postgres on Railway/Render/Supabase) if you expect concurrent traffic.
- Move `JWT_SECRET`, `STRIPE_SECRET_KEY`, etc. into your hosting provider's environment variable settings — never commit `.env`.
- Serve the frontend over HTTPS and update `CLIENT_URL` / Stripe `success_url` / `cancel_url` to your real domain.
- Switch Stripe from test keys to live keys once you're ready to accept real payments.
- Change the seeded admin password immediately.
