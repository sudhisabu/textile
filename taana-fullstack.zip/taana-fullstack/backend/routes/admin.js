const express = require('express');
const db = require('../config/db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/admin/stats — dashboard numbers
router.get('/stats', authenticate, requireAdmin, (req, res) => {
  const productCount = db.prepare('SELECT COUNT(*) AS c FROM products').get().c;
  const orderCount = db.prepare('SELECT COUNT(*) AS c FROM orders').get().c;
  const customerCount = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'customer'").get().c;
  const revenue = db.prepare("SELECT COALESCE(SUM(total),0) AS s FROM orders WHERE status IN ('paid','shipped','delivered')").get().s;
  const pendingOrders = db.prepare("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'").get().c;

  res.json({ productCount, orderCount, customerCount, revenue, pendingOrders });
});

module.exports = router;
