const express = require('express');
const db = require('../config/db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// POST /api/orders — logged-in customer creates an order from their cart
// body: { items: [{ productId?, name, price, qty }], shipping: { name, address, phone } }
router.post('/', authenticate, (req, res) => {
  const { items, shipping } = req.body;
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Cart is empty.' });
  }

  const subtotal = items.reduce((sum, i) => sum + Number(i.price) * Number(i.qty), 0);
  const total = subtotal; // add tax/shipping calculation here if needed

  const insertOrder = db.prepare(`
    INSERT INTO orders (user_id, status, subtotal, total, shipping_name, shipping_address, shipping_phone)
    VALUES (?, 'pending', ?, ?, ?, ?, ?)
  `);
  const insertItem = db.prepare(`
    INSERT INTO order_items (order_id, product_id, name, price, qty) VALUES (?, ?, ?, ?, ?)
  `);

  const createOrder = db.transaction(() => {
    const info = insertOrder.run(
      req.user.id, subtotal, total,
      shipping?.name || req.user.name, shipping?.address || '', shipping?.phone || ''
    );
    const orderId = info.lastInsertRowid;
    for (const item of items) {
      insertItem.run(orderId, item.productId || null, item.name, item.price, item.qty);
    }
    return orderId;
  });

  const orderId = createOrder();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const orderItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);
  res.status(201).json({ order: { ...order, items: orderItems } });
});

// GET /api/orders/me — logged-in customer's own orders
router.get('/me', authenticate, (req, res) => {
  const orders = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  const withItems = orders.map(o => ({
    ...o,
    items: db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id)
  }));
  res.json({ orders: withItems });
});

// GET /api/orders — admin: all orders
router.get('/', authenticate, requireAdmin, (req, res) => {
  const orders = db.prepare(`
    SELECT orders.*, users.name AS customer_name, users.email AS customer_email
    FROM orders JOIN users ON users.id = orders.user_id
    ORDER BY orders.created_at DESC
  `).all();
  const withItems = orders.map(o => ({
    ...o,
    items: db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id)
  }));
  res.json({ orders: withItems });
});

// PUT /api/orders/:id/status — admin updates order status
router.put('/:id/status', authenticate, requireAdmin, (req, res) => {
  const { status } = req.body;
  const allowed = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status.' });

  const info = db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Order not found.' });
  res.json({ ok: true });
});

module.exports = router;
