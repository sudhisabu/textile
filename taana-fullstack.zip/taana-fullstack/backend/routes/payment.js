const express = require('express');
const Stripe = require('stripe');
const db = require('../config/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '');

// POST /api/payment/create-checkout-session — logged-in customer pays for an order
router.post('/create-checkout-session', authenticate, async (req, res) => {
  const { orderId } = req.body;
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(orderId, req.user.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);
  if (items.length === 0) return res.status(400).json({ error: 'Order has no items.' });

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: items.map(item => ({
        price_data: {
          currency: 'inr',
          product_data: { name: item.name },
          unit_amount: Math.round(item.price * 100), // paise
        },
        quantity: item.qty,
      })),
      success_url: `${process.env.CLIENT_URL}/?payment=success&order=${orderId}`,
      cancel_url: `${process.env.CLIENT_URL}/?payment=cancelled&order=${orderId}`,
      metadata: { orderId: String(orderId) },
    });

    db.prepare('UPDATE orders SET stripe_session_id = ? WHERE id = ?').run(session.id, orderId);
    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe error:', err.message);
    res.status(500).json({ error: 'Could not start payment. Check your Stripe keys in .env.' });
  }
});

// POST /api/payment/webhook — Stripe calls this after payment completes.
// NOTE: this route is mounted with express.raw() in server.js (must stay unparsed JSON for signature check).
router.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const orderId = session.metadata?.orderId;
    if (orderId) {
      db.prepare("UPDATE orders SET status = 'paid' WHERE id = ?").run(orderId);
      console.log(`Order ${orderId} marked as paid.`);
    }
  }

  res.json({ received: true });
});

module.exports = router;
