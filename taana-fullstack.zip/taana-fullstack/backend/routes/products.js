const express = require('express');
const db = require('../config/db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/products?category=saree — public
router.get('/', (req, res) => {
  const { category } = req.query;
  const rows = category && category !== 'all'
    ? db.prepare('SELECT * FROM products WHERE category = ? ORDER BY created_at DESC').all(category)
    : db.prepare('SELECT * FROM products ORDER BY created_at DESC').all();
  res.json({ products: rows });
});

// GET /api/products/:id — public
router.get('/:id', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  res.json({ product });
});

// POST /api/products — admin only
router.post('/', authenticate, requireAdmin, (req, res) => {
  const { name, description, price, compare_at_price, category, image_url, stock, is_featured } = req.body;
  if (!name || !price || !category) return res.status(400).json({ error: 'Name, price and category are required.' });

  const info = db.prepare(`
    INSERT INTO products (name, description, price, compare_at_price, category, image_url, stock, is_featured)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(name, description || '', price, compare_at_price || null, category, image_url || '', stock || 0, is_featured ? 1 : 0);

  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ product });
});

// PUT /api/products/:id — admin only
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Product not found.' });

  const fields = ['name', 'description', 'price', 'compare_at_price', 'category', 'image_url', 'stock', 'is_featured'];
  const updated = { ...existing, ...req.body };

  db.prepare(`
    UPDATE products SET name=?, description=?, price=?, compare_at_price=?, category=?, image_url=?, stock=?, is_featured=?
    WHERE id=?
  `).run(
    updated.name, updated.description, updated.price, updated.compare_at_price,
    updated.category, updated.image_url, updated.stock, updated.is_featured ? 1 : 0, req.params.id
  );

  res.json({ product: db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id) });
});

// DELETE /api/products/:id — admin only
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  const info = db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Product not found.' });
  res.json({ ok: true });
});

module.exports = router;
