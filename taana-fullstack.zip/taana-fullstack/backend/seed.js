require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./config/db');

// --- Admin user ---
const adminEmail = (process.env.ADMIN_EMAIL || 'admin@taana.store').toLowerCase();
const existingAdmin = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);

if (!existingAdmin) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin@12345', 10);
  db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
    .run(process.env.ADMIN_NAME || 'Taana Admin', adminEmail, hash, 'admin');
  console.log(`Admin created — email: ${adminEmail}  password: ${process.env.ADMIN_PASSWORD || 'Admin@12345'}`);
} else {
  console.log('Admin already exists, skipping.');
}

// --- Sample products (matches the frontend demo data) ---
const productCount = db.prepare('SELECT COUNT(*) AS c FROM products').get().c;
if (productCount === 0) {
  const insert = db.prepare(`
    INSERT INTO products (name, description, price, compare_at_price, category, image_url, stock, is_featured)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const sample = [
    ['Indigo Ikat Saree', 'Pochampally cotton ikat, hand-dyed in natural indigo.', 4200, null, 'saree', 'https://placehold.co/500x650/26364A/F5EFE4?text=Indigo+Ikat+Saree', 12, 1],
    ['Madder Block Print (2m)', 'Ajrakh hand block print on cotton, natural madder dye.', 1850, 2100, 'fabric', 'https://placehold.co/500x650/B5482A/F5EFE4?text=Madder+Block+Print', 20, 1],
    ['Charcoal Handloom Kurta', 'Khadi cotton kurta, breathable handloom weave.', 2600, null, 'men', 'https://placehold.co/500x650/2A231E/F5EFE4?text=Charcoal+Kurta', 15, 0],
    ['Turmeric Table Runner', 'Chanderi weave table runner, turmeric-dyed.', 1200, null, 'home', 'https://placehold.co/500x650/D9A441/2A231E?text=Table+Runner', 25, 0],
    ['Tussar Silk Saree', 'Bhagalpur tussar silk, unbleached natural sheen.', 6800, null, 'saree', 'https://placehold.co/500x650/26364A/F5EFE4?text=Tussar+Silk+Saree', 8, 1],
    ['Kalamkari Yardage (3m)', 'Hand-painted Srikalahasti kalamkari on cotton.', 3100, null, 'fabric', 'https://placehold.co/500x650/B5482A/F5EFE4?text=Kalamkari+Yardage', 10, 0],
    ['Ivory Linen Shirt', 'Handloom linen shirt, relaxed fit.', 2950, null, 'men', 'https://placehold.co/500x650/2A231E/F5EFE4?text=Ivory+Linen+Shirt', 14, 0],
    ['Woven Cushion Set (2)', 'Cotton jacquard cushion covers, set of two.', 1650, null, 'home', 'https://placehold.co/500x650/D9A441/2A231E?text=Cushion+Set', 18, 0],
  ];
  const insertMany = db.transaction((rows) => rows.forEach(r => insert.run(...r)));
  insertMany(sample);
  console.log(`Inserted ${sample.length} sample products.`);
} else {
  console.log('Products already exist, skipping.');
}

console.log('Seed complete.');
