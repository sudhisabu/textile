require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const paymentRoutes = require('./routes/payment');
const adminRoutes = require('./routes/admin');

const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || '*' }));

// Stripe webhook needs the RAW body, so it must be registered BEFORE express.json().
app.use('/api/payment/webhook', express.raw({ type: 'application/json' }));
app.use(express.json());

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/admin', adminRoutes);

// Static admin panel (plain HTML/JS — no build step) served at /admin
app.use('/admin', express.static(path.join(__dirname, 'public', 'admin')));

app.get('/', (req, res) => res.json({ ok: true, message: 'Taana API is running. Admin panel at /admin' }));

app.use((req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Taana API running on http://localhost:${PORT}  (admin panel: http://localhost:${PORT}/admin)`));
